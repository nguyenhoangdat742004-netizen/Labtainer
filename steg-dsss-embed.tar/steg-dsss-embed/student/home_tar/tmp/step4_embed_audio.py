import numpy as np
import soundfile as sf

# =========================
# Đọc audio
# =========================

audio, sample_rate = sf.read("input.wav")

print("Sample Rate:", sample_rate)
print("Audio Shape:", audio.shape)

# =========================
# Đọc spread signal
# =========================

spread_signal = np.loadtxt(
    "spread_signal.txt"
)

# =========================
# Kéo dài spread signal
# =========================

spread_signal = np.tile(
    spread_signal,
    int(len(audio) / len(spread_signal)) + 1
)

spread_signal = spread_signal[:len(audio)]

print("Extended Spread Length:")
print(len(spread_signal))

# =========================
# Embed DSSS
# =========================

alpha = 0.005

stego_audio = audio + alpha * spread_signal

print("Embedding complete")

# =========================
# Normalize
# =========================

stego_audio = stego_audio / np.max(
    np.abs(stego_audio)
)

print("Normalization complete")

# =========================
# Ghi stego audio
# =========================

sf.write(
    "stego.wav",
    stego_audio,
    sample_rate
)

print("STEGO AUDIO CREATED!")
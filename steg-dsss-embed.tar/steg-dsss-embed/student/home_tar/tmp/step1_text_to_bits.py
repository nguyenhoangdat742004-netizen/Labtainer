import numpy as np
import sys

# =========================
# Đọc message
# =========================

with open("message.txt", "r") as f:
    message = f.read().strip()

print("Secret Message:")
print(message)

# =========================
# Text -> Bits
# =========================

def text_to_bits(text):

    bits = []

    for char in text:

        binary = format(ord(char), '08b')

        for b in binary:
            bits.append(int(b))

    return np.array(bits)

message_bits = text_to_bits(message)

print("Message bits:")
print(message_bits)

# =========================
# Lưu bits
# =========================

np.savetxt(
    "bits.txt",
    message_bits,
    fmt='%d'
)

print("bits.txt created")
import numpy as np
import soundfile as sf

# =========================
# Đọc stego audio
# =========================

audio, sample_rate = sf.read("stego.wav")

print("Sample Rate:", sample_rate)
print("Audio Length:", len(audio))

# =========================
# PN code (phải giống sender)
# =========================

pn_code = np.array([1, -1, 1, 1, -1, 1, -1, -1])

chips_per_bit = len(pn_code)

# =========================
# Số bit cần recover
# "HELLO" = 5 ký tự
# 5 * 8 = 40 bits
# =========================

num_bits = 40

# =========================
# Extract DSSS signal
# =========================

recovered_bits = []

for i in range(num_bits):

    start = i * chips_per_bit

    end = start + chips_per_bit

    segment = audio[start:end]

    correlation = np.sum(segment * pn_code)

    if correlation > 0:
        recovered_bits.append(1)
    else:
        recovered_bits.append(0)

print("Recovered Bits:")
print(recovered_bits)

# =========================
# Bits -> Text
# =========================

chars = []

for i in range(0, len(recovered_bits), 8):

    byte = recovered_bits[i:i+8]

    byte_str = ''.join(map(str, byte))

    chars.append(chr(int(byte_str, 2)))

message = ''.join(chars)

print("Recovered Message:")
print(message)
import numpy as np

# =========================
# Đọc bits
# =========================

message_bits = np.loadtxt(
    "bits.txt",
    dtype=int
)

# =========================
# Đọc PN code
# =========================

pn_code = np.loadtxt(
    "pn_code.txt",
    dtype=int
)

# =========================
# BPSK
# =========================

bpsk_bits = np.where(
    message_bits == 1,
    1,
    -1
)

print("BPSK bits:")
print(bpsk_bits)

# =========================
# DSSS spreading
# =========================

spread_signal = np.array([])

for bit in bpsk_bits:

    spread_bit = bit * pn_code

    spread_signal = np.concatenate(
        (spread_signal, spread_bit)
    )

print("Spread Signal Length:")
print(len(spread_signal))

# =========================
# Lưu spread signal
# =========================

np.savetxt(
    "spread_signal.txt",
    spread_signal,
    fmt='%d'
)

print("spread_signal.txt created")
import numpy as np
import soundfile as sf
import os

# Đọc audio

original, sr1 = sf.read("input.wav")

stego, sr2 = sf.read("stego.wav")

# =========================
# Tính MSE
# =========================

mse = np.mean((original - stego) ** 2)

print("MSE:", mse)

# =========================
# So sánh kích thước file
# =========================

original_size = os.path.getsize("input.wav")

stego_size = os.path.getsize("stego.wav")

print("Original Size:", original_size, "bytes")

print("Stego Size:", stego_size, "bytes")
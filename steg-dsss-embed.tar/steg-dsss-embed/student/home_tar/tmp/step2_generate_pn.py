import numpy as np

# =========================
# PN Code DSSS
# =========================

pn_code = np.array([1, -1, 1, 1, -1, 1, -1, -1])

print("PN Code:")
print(pn_code)

# =========================
# Lưu PN code
# =========================

np.savetxt(
    "pn_code.txt",
    pn_code,
    fmt='%d'
)

print("pn_code.txt created")
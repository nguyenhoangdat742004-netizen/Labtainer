import numpy as np
import soundfile as sf

audio, sr = sf.read("stego.wav")

# Gaussian noise
noise = np.random.normal(0, 0.01, len(audio))

noisy_audio = audio + noise

# normalize
noisy_audio = noisy_audio / np.max(np.abs(noisy_audio))

sf.write("noisy_stego.wav", noisy_audio, sr)

print("Noisy audio created!")
import numpy as np

# Original bits
original_bits = []

message = "HELLO"

for char in message:
    binary = format(ord(char), '08b')
    for b in binary:
        original_bits.append(int(b))

original_bits = np.array(original_bits)

# Recovered bits
recovered_bits = np.loadtxt(
    "recovered_bits.txt",
    dtype=int
)

# BER
errors = np.sum(original_bits != recovered_bits)

ber = errors / len(original_bits)

print("Total bits:", len(original_bits))
print("Bit Errors:", errors)
print("BER:", ber)

# ========================================================
# ĐOẠN THÊM VÀO: Tự động ghi kết quả BER ra file ber_result.txt
# ========================================================
with open("ber_result.txt", "w") as f:
    f.write(f"{ber:.1f}") 

print("BER result saved to ber_result.txt!")

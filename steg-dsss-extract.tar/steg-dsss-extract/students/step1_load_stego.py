import soundfile as sf

audio, sample_rate = sf.read("stego.wav")

print("Sample Rate:", sample_rate)
print("Audio Length:", len(audio))

print("First 20 samples:")
print(audio[:20])
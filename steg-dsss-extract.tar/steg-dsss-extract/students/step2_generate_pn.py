import numpy as np

pn_code = np.array([1, -1, 1, 1, -1, 1, -1, -1])

print("PN Code:")
print(pn_code)

np.savetxt("pn_code.txt", pn_code, fmt='%d')

print("PN code saved!")
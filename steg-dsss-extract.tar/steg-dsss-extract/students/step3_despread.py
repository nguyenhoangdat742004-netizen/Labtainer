import numpy as np
import soundfile as sf

# =========================
# Đọc stego audio
# =========================

audio, sample_rate = sf.read("stego.wav")

# =========================
# PN code
# =========================

pn_code = np.array([1, -1, 1, 1, -1, 1, -1, -1])

chips_per_bit = len(pn_code)

# =========================
# HELLO = 40 bits
# =========================

num_bits = 40

recovered_bits = []

# =========================
# Correlation detection
# =========================

for i in range(num_bits):

    start = i * chips_per_bit

    end = start + chips_per_bit

    segment = audio[start:end]

    correlation = np.sum(segment * pn_code)

    if correlation > 0:
        recovered_bits.append(1)
    else:
        recovered_bits.append(0)

print("Recovered Bits:")
print(recovered_bits)

np.savetxt("recovered_bits.txt",
           recovered_bits,
           fmt='%d')

print("Recovered bits saved!")